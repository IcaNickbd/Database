-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema universitylab
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema universitylab
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `universitylab` DEFAULT CHARACTER SET utf8 ;
USE `universitylab` ;

-- -----------------------------------------------------
-- Table `universitylab`.`Department`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `universitylab`.`Department` (
  `DepartmentID` INT NOT NULL,
  `Name` VARCHAR(45) NULL,
  `Address` VARCHAR(45) NULL,
  `Contactdetails` VARCHAR(45) NULL,
  PRIMARY KEY (`DepartmentID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `universitylab`.`FacultyMember`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `universitylab`.`FacultyMember` (
  `FacultyID` INT NOT NULL,
  `Name` VARCHAR(45) NULL,
  `Designation` VARCHAR(45) NULL,
  `Startdate` DATE NULL,
  `DepartmentID` INT NOT NULL,
  PRIMARY KEY (`FacultyID`),
  INDEX `fk_Facultymember_Department_idx` (`DepartmentID` ASC) VISIBLE,
  CONSTRAINT `fk_Facultymember_Department`
    FOREIGN KEY (`DepartmentID`)
    REFERENCES `universitylab`.`Department` (`DepartmentID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `universitylab`.`Module`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `universitylab`.`Module` (
  `ModuleID` INT NOT NULL,
  `Title` VARCHAR(45) NULL,
  `CreditHours` INT NULL,
  `ModuleDescription` VARCHAR(45) NULL,
  `DepartmentID` INT NOT NULL,
  PRIMARY KEY (`ModuleID`),
  INDEX `fk_Module_Department1_idx` (`DepartmentID` ASC) VISIBLE,
  CONSTRAINT `fk_Module_Department1`
    FOREIGN KEY (`DepartmentID`)
    REFERENCES `universitylab`.`Department` (`DepartmentID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `universitylab`.`Student`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `universitylab`.`Student` (
  `StudentID` INT NOT NULL,
  `Name` VARCHAR(45) NULL,
  `Programcode` VARCHAR(45) NULL,
  `DepartmentID` INT NOT NULL,
  PRIMARY KEY (`StudentID`),
  INDEX `fk_Student_Department1_idx` (`DepartmentID` ASC) VISIBLE,
  CONSTRAINT `fk_Student_Department1`
    FOREIGN KEY (`DepartmentID`)
    REFERENCES `universitylab`.`Department` (`DepartmentID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `universitylab`.`Lecture`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `universitylab`.`Lecture` (
  `LectureID` INT NOT NULL,
  `Semester` VARCHAR(45) NULL,
  `Year` INT NULL,
  `Date` DATE NULL,
  `FacultyID` INT NOT NULL,
  `ModuleID` INT NOT NULL,
  PRIMARY KEY (`LectureID`),
  INDEX `fk_Lecture_Facultymember1_idx` (`FacultyID` ASC) VISIBLE,
  INDEX `fk_Lecture_Module1_idx` (`ModuleID` ASC) VISIBLE,
  CONSTRAINT `fk_Lecture_Facultymember1`
    FOREIGN KEY (`FacultyID`)
    REFERENCES `universitylab`.`FacultyMember` (`FacultyID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Lecture_Module1`
    FOREIGN KEY (`ModuleID`)
    REFERENCES `universitylab`.`Module` (`ModuleID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `universitylab`.`Grade`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `universitylab`.`Grade` (
  `StudentID` INT NOT NULL,
  `ModuleID` INT NOT NULL,
  `GradeID` VARCHAR(45) NULL,
  `Grade` VARCHAR(45) NULL,
  PRIMARY KEY (`StudentID`, `ModuleID`),
  INDEX `fk_Student_has_Module_Module1_idx` (`ModuleID` ASC) VISIBLE,
  INDEX `fk_Student_has_Module_Student1_idx` (`StudentID` ASC) VISIBLE,
  CONSTRAINT `fk_Student_has_Module_Student1`
    FOREIGN KEY (`StudentID`)
    REFERENCES `universitylab`.`Student` (`StudentID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Student_has_Module_Module1`
    FOREIGN KEY (`ModuleID`)
    REFERENCES `universitylab`.`Module` (`ModuleID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
