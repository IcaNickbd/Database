-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema doughnutshop
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema doughnutshop
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `doughnutshop` DEFAULT CHARACTER SET utf8 ;
USE `doughnutshop` ;

-- -----------------------------------------------------
-- Table `doughnutshop`.`menus`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `doughnutshop`.`menus` (
  `menu_id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NULL,
  `type` ENUM('regular', 'seasonal') NOT NULL,
  `start_date` DATE NULL,
  `end_date` DATE NULL,
  `color_palette` VARCHAR(45) NULL,
  PRIMARY KEY (`menu_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `doughnutshop`.`products`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `doughnutshop`.`products` (
  `product_id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `price` DECIMAL(10,2) NOT NULL,
  `calories` INT NULL,
  `sugar_content` DECIMAL(5,2) NULL,
  `protein` DECIMAL(5,2) NULL,
  `salt` DECIMAL(5,2) NULL,
  `menu_id` INT NOT NULL,
  PRIMARY KEY (`product_id`),
  INDEX `fk_products_menus_idx` (`menu_id` ASC) VISIBLE,
  CONSTRAINT `fk_products_menus`
    FOREIGN KEY (`menu_id`)
    REFERENCES `doughnutshop`.`menus` (`menu_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `doughnutshop`.`buyers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `doughnutshop`.`buyers` (
  `buyers_id` INT NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NULL,
  `last_name` VARCHAR(45) NULL,
  `gender` ENUM('male', 'female', 'other') NULL,
  `age` INT NULL,
  `occupation` VARCHAR(45) NULL,
  PRIMARY KEY (`buyers_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `doughnutshop`.`employees`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `doughnutshop`.`employees` (
  `employee_id` INT NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NULL,
  `last_name` VARCHAR(45) NULL,
  `contract_type` ENUM('full-time', 'part-time') NULL,
  `total_working_hours` DECIMAL(5,2) NULL,
  `overtime` DECIMAL(5,2) NULL,
  `years_of_experience` INT NULL,
  PRIMARY KEY (`employee_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `doughnutshop`.`branches`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `doughnutshop`.`branches` (
  `branch_id` INT NOT NULL AUTO_INCREMENT,
  `address` VARCHAR(255) NULL,
  `size` INT NULL,
  PRIMARY KEY (`branch_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `doughnutshop`.`ingredients`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `doughnutshop`.`ingredients` (
  `ingredient_id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `country_of_origin` VARCHAR(45) NULL,
  `units_purchased` INT NULL,
  `price` DECIMAL(5,2) NULL,
  `supplier_name` VARCHAR(45) NULL,
  PRIMARY KEY (`ingredient_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `doughnutshop`.`products_ingredients`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `doughnutshop`.`products_ingredients` (
  `products_product_id` INT NOT NULL,
  `ingredients_ingredient_id` INT NOT NULL,
  `quantity` INT NULL,
  PRIMARY KEY (`products_product_id`, `ingredients_ingredient_id`),
  INDEX `fk_products_has_ingredients_ingredients1_idx` (`ingredients_ingredient_id` ASC) VISIBLE,
  INDEX `fk_products_has_ingredients_products1_idx` (`products_product_id` ASC) VISIBLE,
  CONSTRAINT `fk_products_has_ingredients_products1`
    FOREIGN KEY (`products_product_id`)
    REFERENCES `doughnutshop`.`products` (`product_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_products_has_ingredients_ingredients1`
    FOREIGN KEY (`ingredients_ingredient_id`)
    REFERENCES `doughnutshop`.`ingredients` (`ingredient_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `doughnutshop`.`sales`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `doughnutshop`.`sales` (
  `sale_id` INT NOT NULL AUTO_INCREMENT,
  `sale_time` DATETIME NULL,
  `price` DECIMAL(10,2) NULL,
  `product_id` INT NOT NULL,
  `buyer_id` INT NOT NULL,
  `employee_id` INT NOT NULL,
  `branch_id` INT NOT NULL,
  PRIMARY KEY (`sale_id`),
  INDEX `fk_sales_products1_idx` (`product_id` ASC) VISIBLE,
  INDEX `fk_sales_buyers1_idx` (`buyer_id` ASC) VISIBLE,
  INDEX `fk_sales_employees1_idx` (`employee_id` ASC) VISIBLE,
  INDEX `fk_sales_branches1_idx` (`branch_id` ASC) VISIBLE,
  CONSTRAINT `fk_sales_products1`
    FOREIGN KEY (`product_id`)
    REFERENCES `doughnutshop`.`products` (`product_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_sales_buyers1`
    FOREIGN KEY (`buyer_id`)
    REFERENCES `doughnutshop`.`buyers` (`buyers_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_sales_employees1`
    FOREIGN KEY (`employee_id`)
    REFERENCES `doughnutshop`.`employees` (`employee_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_sales_branches1`
    FOREIGN KEY (`branch_id`)
    REFERENCES `doughnutshop`.`branches` (`branch_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
