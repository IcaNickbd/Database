-- Task 6 SQL QUERY--
-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema hospital1
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema hospital1
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `hospital1` DEFAULT CHARACTER SET utf8 ;
USE `hospital1` ;

-- -----------------------------------------------------
-- Table `hospital1`.`Residents`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hospital1`.`Residents` (
  `ResidentID` VARCHAR(45) NOT NULL,
  `Name` VARCHAR(45) NOT NULL,
  `Address` VARCHAR(255) NULL,
  `PhoneNumber` VARCHAR(45) NULL,
  `DateOfBirth` DATE NULL,
  `Gender` VARCHAR(45) NULL,
  `AllergyHistory` TEXT NULL,
  `HealthNotes` TEXT NULL,
  PRIMARY KEY (`ResidentID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `hospital1`.`Guardians`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hospital1`.`Guardians` (
  `GuardianID` VARCHAR(45) NOT NULL,
  `Name` VARCHAR(45) NULL,
  `Address` TEXT NULL,
  `PhoneNumber` VARCHAR(45) NULL,
  `WechatID` VARCHAR(45) NULL,
  PRIMARY KEY (`GuardianID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `hospital1`.`Residents_Guardians`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hospital1`.`Residents_Guardians` (
  `Residents_ResidentID` VARCHAR(45) NOT NULL,
  `Guardians_GuardianID` VARCHAR(45) NOT NULL,
  `Relationship` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`Residents_ResidentID`, `Guardians_GuardianID`),
  INDEX `fk_Residents_has_Guardians_Guardians1_idx` (`Guardians_GuardianID` ASC) VISIBLE,
  INDEX `fk_Residents_has_Guardians_Residents_idx` (`Residents_ResidentID` ASC) VISIBLE,
  CONSTRAINT `fk_Residents_has_Guardians_Residents`
    FOREIGN KEY (`Residents_ResidentID`)
    REFERENCES `hospital1`.`Residents` (`ResidentID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Residents_has_Guardians_Guardians1`
    FOREIGN KEY (`Guardians_GuardianID`)
    REFERENCES `hospital1`.`Guardians` (`GuardianID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `hospital1`.`UserRole`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hospital1`.`UserRole` (
  `UserID` INT NOT NULL,
  `Username` VARCHAR(45) NULL,
  `Password` VARCHAR(45) NULL,
  PRIMARY KEY (`UserID`),
  INDEX `key` (`UserID` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `hospital1`.`CareLog`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hospital1`.`CareLog` (
  `CareLogID` INT NOT NULL,
  `Content` VARCHAR(45) NULL,
  `RecordTime` DATETIME NULL,
  `ResidentID` VARCHAR(45) NOT NULL,
  `CaregiverID` INT NOT NULL,
  PRIMARY KEY (`CareLogID`),
  INDEX `fk_CareLog_Residents1_idx` (`ResidentID` ASC) VISIBLE,
  INDEX `fk_CareLog_UserRole1_idx` (`CaregiverID` ASC) VISIBLE,
  CONSTRAINT `fk_CareLog_Residents1`
    FOREIGN KEY (`ResidentID`)
    REFERENCES `hospital1`.`Residents` (`ResidentID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_CareLog_UserRole1`
    FOREIGN KEY (`CaregiverID`)
    REFERENCES `hospital1`.`UserRole` (`UserID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `hospital1`.`HealthRecord`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hospital1`.`HealthRecord` (
  `HealthRecordID` INT NOT NULL,
  `Content` TEXT NULL,
  `RecordTime` DATETIME NULL,
  `ResidentID` VARCHAR(45) NOT NULL,
  `NurseID` INT NOT NULL,
  PRIMARY KEY (`HealthRecordID`),
  INDEX `fk_HealthRecord_Residents1_idx` (`ResidentID` ASC) VISIBLE,
  INDEX `fk_HealthRecord_UserRole1_idx` (`NurseID` ASC) VISIBLE,
  CONSTRAINT `fk_HealthRecord_Residents1`
    FOREIGN KEY (`ResidentID`)
    REFERENCES `hospital1`.`Residents` (`ResidentID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_HealthRecord_UserRole1`
    FOREIGN KEY (`NurseID`)
    REFERENCES `hospital1`.`UserRole` (`UserID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `hospital1`.`Role`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hospital1`.`Role` (
  `RoleID` INT NOT NULL,
  `RoleName` VARCHAR(45) NULL,
  PRIMARY KEY (`RoleID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `hospital1`.`RolePermission`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hospital1`.`RolePermission` (
  `PermissionId` INT NOT NULL,
  `Permission` VARCHAR(255) NULL,
  `Role_RoleID` INT NOT NULL,
  PRIMARY KEY (`PermissionId`),
  INDEX `fk_RolePermission_Role1_idx` (`Role_RoleID` ASC) VISIBLE,
  CONSTRAINT `fk_RolePermission_Role1`
    FOREIGN KEY (`Role_RoleID`)
    REFERENCES `hospital1`.`Role` (`RoleID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `hospital1`.`UserRoleMapping`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hospital1`.`UserRoleMapping` (
  `UserID` INT NOT NULL,
  `RoleID` INT NOT NULL,
  PRIMARY KEY (`UserID`, `RoleID`),
  INDEX `fk_UserRole_has_Role_Role1_idx` (`RoleID` ASC) VISIBLE,
  INDEX `fk_UserRole_has_Role_UserRole1_idx` (`UserID` ASC) VISIBLE,
  CONSTRAINT `fk_UserRole_has_Role_UserRole1`
    FOREIGN KEY (`UserID`)
    REFERENCES `hospital1`.`UserRole` (`UserID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_UserRole_has_Role_Role1`
    FOREIGN KEY (`RoleID`)
    REFERENCES `hospital1`.`Role` (`RoleID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;



-- Task 7 SQL Query --
use hospital1
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('224360184286272079', 'Harry Hendricks', '9671 Gillespie Greens Suite 156, Kelseychester, WV 18335', '18497938812', '1960-07-11', 'Male', 'Myself red will short.', 'Fly offer let friend room.');
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('853501313039236018', 'Donald Hudson', '13751 Brown Mission, North Patrickbury, UT 56920', '17529323589', '1991-04-26', 'Female', 'Kitchen heart course.', 'Section story marriage whatever event not.');
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('583773561162563849', 'Catherine Ellis', 'Unit 6321 Box 5409, DPO AP 26235', '13248903232', '1996-04-28', 'Female', 'Buy sell per save service.', 'One first direction.');
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('237764376038920434', 'Aaron Hernandez', '32611 Austin Ferry Apt. 536, Lake Timothy, HI 32023', '16183286768', '1985-04-12', 'Male', 'Trip computer travel occur be realize.', 'Specific cultural thought carry yeah.');
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('127218669357785025', 'Mary Harris', 'PSC 7841, Box 8290, APO AA 78597', '18628409591', '1934-02-20', 'Female', 'Nice Republican official.', 'Rather energy image offer society notice.');
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('490946937910629327', 'Keith Scott', '440 Leach Junctions Suite 906, Laurenfurt, NH 02644', '11710175702', '1959-07-25', 'Female', 'Couple wind wide.', 'Front whether candidate.');
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('549239379508031642', 'Dale Mccann', '342 James Common, Pageport, MT 58210', '15481071444', '1974-07-13', 'Female', 'Other current on law.', 'Including dog task task.');
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('361595796296662468', 'Erik Miller', '757 Johnson Groves Apt. 851, Leahborough, ID 52339', '14347147139', '1961-09-04', 'Male', 'Five top car car far.', 'Meet social once chance information.');
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('508386820364847588', 'Dustin Lozano PhD', '38317 Michael Ridge Apt. 573, Amandaside, CA 50936', '17236441007', '1992-04-26', 'Male', 'Until floor writer away hotel grow.', 'Town magazine break.');
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('373572786734420775', 'Bobby Hoffman', 'USCGC Brown, FPO AP 54889', '15856295720', '1946-01-26', 'Female', 'Five discuss traditional allow figure whether.', 'Media thousand another number player.');
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('454548493233095354', 'Paula Barker', 'PSC 2833, Box 1840, APO AA 59543', '14942256882', '1972-07-20', 'Male', 'Factor kid draw will.', 'Yourself population measure manager exactly member.');
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('411613850940565994', 'David Smith', '0015 Stacey Meadow Suite 325, Port Kara, WI 33417', '12554240887', '1999-06-22', 'Male', 'Until building eye compare every base.', 'Country situation memory.');
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('536650398720491908', 'Karen Torres', '812 Taylor Course Apt. 688, West David, WI 91862', '11496834863', '1967-10-18', 'Male', 'We everybody claim those special kid.', 'Buy use box water.');
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('681868195649053989', 'Eric Long', '3793 Richardson Locks Suite 390, North Jacqueline, FL 04345', '16857563658', '1977-04-19', 'Female', 'Believe professor wrong discussion people way.', 'Continue church thus news interesting.');
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('231095816878478628', 'Roberta Anderson', '780 Garrett Road Apt. 452, Ronniemouth, AL 21188', '18708606725', '1966-04-06', 'Male', 'Back give quite take call democratic.', 'Nor side college within song relationship.');
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('353163091806114367', 'Kenneth Reid', '85323 Martin Centers, Lake Aliciachester, LA 86520', '12686782852', '1965-09-06', 'Male', 'Share during represent reveal factor.', 'Lose because bit hope.');
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('212750573394927405', 'Meghan Long', '5937 Amber Valley, Amyfurt, AZ 96942', '15634306312', '1973-10-11', 'Male', 'Spring house if.', 'Gun main cover prove father.');
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('636910012308914241', 'Tyrone Walker', '207 Karen Squares, East Nathan, IA 65792', '19282758434', '1980-05-23', 'Male', 'Contain system art forget born.', 'Difference politics under glass generation.');
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('970762394927732020', 'Theresa Collier', 'USS Vasquez, FPO AA 49729', '14873888913', '1962-05-23', 'Female', 'Exactly stock PM simply.', 'Cut become meeting effect.');
INSERT INTO Residents (ResidentID, Name, Address, PhoneNumber, DateOfBirth, Gender, AllergyHistory, HealthNotes) VALUES ('870670449030532361', 'Samuel Sullivan', '7004 Hale Square Suite 223, Montesport, AZ 09301', '14494488097', '1981-11-03', 'Female', 'Fight those Democrat game already.', 'Discover shoulder mention make apply impact.');

INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('047407006853525560', 'Kenneth Hernandez', '709 Patricia Locks, North Heidi, ND 44262', '19501575689', 'murrayelizabeth');
INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('817297387357544316', 'Melissa Rodriguez', '22667 Ashley Highway Apt. 356, West Donna, TX 41232', '13195539962', 'alex79');
INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('901360840615820627', 'Yvonne Martin', '164 Robbins Walk, West Wendy, NJ 41516', '14516527621', 'brownjeffrey');
INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('625015803244653833', 'Lance Jimenez', '3178 Lynch Summit Suite 010, Nelsonville, AR 50232', '17668763258', 'johnsonkristine');
INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('358952345726278865', 'Tyler Edwards', '38915 Jackson Harbors, Lake Richardbury, VA 17115', '13657841923', 'newtonjonathan');
INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('711218390183164699', 'Samuel Gilbert', '697 Alyssa Ridge Apt. 254, Christopherberg, ND 57211', '10787914506', 'christinajackson');
INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('946284890379790045', 'Raymond Jackson', '564 Jennifer Springs, North Valeriehaven, NM 23714', '15018556084', 'johnbarrett');
INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('306748414124715583', 'Amanda Rice', '54596 Meredith Landing Suite 796, Jessicaside, FL 33524', '18342255685', 'epowell');
INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('922711898336626043', 'Karen Cobb', '627 Livingston Park Apt. 235, Rachelborough, DC 14639', '18359980005', 'zwest');
INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('375978489541521459', 'Tyler Baird', '682 Michael Mall Apt. 175, Barnesbury, WA 72525', '10783261998', 'christianperry');
INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('713814948362374664', 'Roger Novak', '3506 Victoria Meadow, Lake Jennifer, MA 64628', '11380088818', 'iestrada');
INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('352058981608919021', 'Paul Valencia', '20350 Cruz Branch Suite 066, Port Rebeccaville, NC 93357', '15659739743', 'timothy16');
INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('461648128691895985', 'Scott Walker', '022 Macias Key, South Kara, AK 21972', '19025923910', 'robinsonrobert');
INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('914384994545856339', 'David Medina', '44928 Nicole Manor, New Betty, UT 10301', '15200823637', 'leecrystal');
INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('542002715123277503', 'Brian Barrera', '02149 Joseph Ville, Lake Taylor, DC 75531', '12575513389', 'jordanfleming');
INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('903626736647299806', 'Kenneth Harper', '4387 Shelby Way Apt. 907, East Amber, NM 06167', '13509365703', 'barneswilliam');
INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('441234353806698943', 'Casey Jones', '85205 Jeremy Circle, Andersonburgh, PA 49081', '10854214680', 'ryanroberts');
INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('759934297895786487', 'Brianna Miller', 'PSC 9583, Box 0869, APO AA 53076', '14773246928', 'robert39');
INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('400136994906947935', 'William Owens', '388 Bennett Green, Jeffersonberg, CO 51400', '16135920427', 'vicki89');
INSERT INTO Guardians (GuardianID, Name, Address, PhoneNumber, WechatID) VALUES ('194808531323585349', 'Amy Moreno', '65650 Gardner Harbors, Jamesborough, DE 86507', '18899390450', 'john69');


INSERT INTO UserRole (UserID, Username, Password) VALUES (4491, 'Brian', '925792');
INSERT INTO UserRole (UserID, Username, Password) VALUES (5875, 'Jennifer', '445627');
INSERT INTO UserRole (UserID, Username, Password) VALUES (1461, 'Sheri', '429604');
INSERT INTO UserRole (UserID, Username, Password) VALUES (9483, 'Michael', '081010');
INSERT INTO UserRole (UserID, Username, Password) VALUES (6955, 'Cynthia', '647136');
INSERT INTO UserRole (UserID, Username, Password) VALUES (9931, 'Andrea', '854131');
INSERT INTO UserRole (UserID, Username, Password) VALUES (3154, 'Tiffany', '085301');
INSERT INTO UserRole (UserID, Username, Password) VALUES (5969, 'Courtney', '376983');
INSERT INTO UserRole (UserID, Username, Password) VALUES (8655, 'Breanna', '724368');
INSERT INTO UserRole (UserID, Username, Password) VALUES (7649, 'Jessica', '542278');
INSERT INTO UserRole (UserID, Username, Password) VALUES (8798, 'Wesley', '960248');
INSERT INTO UserRole (UserID, Username, Password) VALUES (9640, 'Kyle', '237504');
INSERT INTO UserRole (UserID, Username, Password) VALUES (4460, 'Tiffany', '627347');
INSERT INTO UserRole (UserID, Username, Password) VALUES (6860, 'Christopher', '206272');
INSERT INTO UserRole (UserID, Username, Password) VALUES (6035, 'Elizabeth', '874846');
INSERT INTO UserRole (UserID, Username, Password) VALUES (1428, 'Ryan', '136226');
INSERT INTO UserRole (UserID, Username, Password) VALUES (1112, 'Nicholas', '885689');
INSERT INTO UserRole (UserID, Username, Password) VALUES (3718, 'Daniel', '134547');
INSERT INTO UserRole (UserID, Username, Password) VALUES (5429, 'Meagan', '416767');
INSERT INTO UserRole (UserID, Username, Password) VALUES (9334, 'Robert', '504254');
INSERT INTO UserRole (UserID, Username, Password) VALUES (1724, 'Anthony', '188523');
INSERT INTO UserRole (UserID, Username, Password) VALUES (8467, 'Stephanie', '601757');
INSERT INTO UserRole (UserID, Username, Password) VALUES (4052, 'Samuel', '976004');
INSERT INTO UserRole (UserID, Username, Password) VALUES (3320, 'Cole', '368725');
INSERT INTO UserRole (UserID, Username, Password) VALUES (3941, 'Joseph', '766683');
INSERT INTO UserRole (UserID, Username, Password) VALUES (1302, 'Monica', '524519');
INSERT INTO UserRole (UserID, Username, Password) VALUES (2138, 'Jennifer', '085761');
INSERT INTO UserRole (UserID, Username, Password) VALUES (9822, 'Tracy', '287555');
INSERT INTO UserRole (UserID, Username, Password) VALUES (4262, 'Emily', '418181');
INSERT INTO UserRole (UserID, Username, Password) VALUES (4129, 'Peggy', '938523');


INSERT INTO HealthRecord (HealthRecordID, Content, RecordTime, ResidentID, NurseID) VALUES (1, 'Minor complications, addressed effectively.', '2024-04-08 09:19:07', '970762394927732020', 5875);
INSERT INTO HealthRecord (HealthRecordID, Content, RecordTime, ResidentID, NurseID) VALUES (2, 'Patient is recovering well.', '2024-08-09 11:06:19', '231095816878478628', 9334);
INSERT INTO HealthRecord (HealthRecordID, Content, RecordTime, ResidentID, NurseID) VALUES (3, 'Stable but under observation.', '2024-07-30 13:00:40', '853501313039236018', 3154);
INSERT INTO HealthRecord (HealthRecordID, Content, RecordTime, ResidentID, NurseID) VALUES (4, 'Critical condition, requires monitoring.', '2024-09-12 13:39:45', '361595796296662468', 4052);
INSERT INTO HealthRecord (HealthRecordID, Content, RecordTime, ResidentID, NurseID) VALUES (5, 'Condition remains stable.', '2024-04-04 20:24:44', '636910012308914241', 1428);
INSERT INTO HealthRecord (HealthRecordID, Content, RecordTime, ResidentID, NurseID) VALUES (6, 'Stable but under observation.', '2024-02-13 06:21:29', '353163091806114367', 9483);
INSERT INTO HealthRecord (HealthRecordID, Content, RecordTime, ResidentID, NurseID) VALUES (7, 'Condition remains stable.', '2024-05-11 06:47:22', '224360184286272079', 5969);
INSERT INTO HealthRecord (HealthRecordID, Content, RecordTime, ResidentID, NurseID) VALUES (8, 'Significant improvement observed.', '2024-03-21 07:40:09', '490946937910629327', 8655);
INSERT INTO HealthRecord (HealthRecordID, Content, RecordTime, ResidentID, NurseID) VALUES (9, 'Significant improvement observed.', '2024-02-11 07:22:34', '212750573394927405', 3718);
INSERT INTO HealthRecord (HealthRecordID, Content, RecordTime, ResidentID, NurseID) VALUES (10, 'Stable but under observation.', '2024-10-19 15:11:42', '549239379508031642', 1112);


INSERT INTO CareLog (CareLogID, Content, RecordTime, ResidentID, CaregiverID) VALUES (1, 'Conducted routine health check-up.', '2024-01-29 22:48:30', '508386820364847588', 6035);
INSERT INTO CareLog (CareLogID, Content, RecordTime, ResidentID, CaregiverID) VALUES (2, 'Provided dietary recommendations.', '2024-09-09 01:09:35', '583773561162563849', 4129);
INSERT INTO CareLog (CareLogID, Content, RecordTime, ResidentID, CaregiverID) VALUES (3, 'Monitored blood pressure and heart rate.', '2024-03-12 01:58:18', '411613850940565994', 3320);
INSERT INTO CareLog (CareLogID, Content, RecordTime, ResidentID, CaregiverID) VALUES (4, 'Applied bandage to minor injuries.', '2024-08-05 07:36:27', '870670449030532361', 1461);
INSERT INTO CareLog (CareLogID, Content, RecordTime, ResidentID, CaregiverID) VALUES (5, 'Assisted with walking exercises.', '2024-08-11 11:48:47', '373572786734420775', 6955);
INSERT INTO CareLog (CareLogID, Content, RecordTime, ResidentID, CaregiverID) VALUES (6, 'Provided dietary recommendations.', '2024-02-08 08:23:05', '237764376038920434', 5875);
INSERT INTO CareLog (CareLogID, Content, RecordTime, ResidentID, CaregiverID) VALUES (7, 'Conducted routine health check-up.', '2024-11-10 19:51:25', '853501313039236018', 3718);
INSERT INTO CareLog (CareLogID, Content, RecordTime, ResidentID, CaregiverID) VALUES (8, 'Applied bandage to minor injuries.', '2024-09-21 07:20:07', '536650398720491908', 1428);
INSERT INTO CareLog (CareLogID, Content, RecordTime, ResidentID, CaregiverID) VALUES (9, 'Checked patient''s respiratory condition.', '2024-06-15 11:10:58', '970762394927732020', 9483);
INSERT INTO CareLog (CareLogID, Content, RecordTime, ResidentID, CaregiverID) VALUES (10, 'Assisted with walking exercises.', '2024-11-14 01:17:23', '454548493233095354', 9822);


INSERT INTO Role (RoleID, RoleName) VALUES (1, 'Caregiver');
INSERT INTO Role (RoleID, RoleName) VALUES (2, 'Nurse');
INSERT INTO Role (RoleID, RoleName) VALUES (3, 'Admin');
INSERT INTO Role (RoleID, RoleName) VALUES (4, 'test1');
INSERT INTO Role (RoleID, RoleName) VALUES (5, 'test2');

INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (5875, 2);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (9334, 2);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (3154, 2);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (4052, 2);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (1428, 2);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (9483, 2);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (5969, 2);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (8655, 2);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (3718, 2);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (1112, 2);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (6035, 1);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (4129, 1);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (3320, 1);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (1461, 1);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (6955, 1);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (5875, 1);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (3718, 1);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (1428, 1);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (9483, 1);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (9822, 1);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (4491, 3);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (9931, 4);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (7649, 5);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (8798, 3);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (9640, 4);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (4460, 5);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (6860, 3);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (5429, 4);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (1724, 5);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (8467, 3);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (3941, 4);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (1302, 5);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (2138, 3);
INSERT INTO UserRoleMapping (UserID, RoleID) VALUES (4262, 4);

INSERT INTO RolePermission (PermissionId, Permission, Role_RoleID) VALUES (1, 'Access CareLog', 1);
INSERT INTO RolePermission (PermissionId, Permission, Role_RoleID) VALUES (2, 'Access HealthRecord', 2);
INSERT INTO RolePermission (PermissionId, Permission, Role_RoleID) VALUES (3, 'Access All Information', 3);
INSERT INTO RolePermission (PermissionId, Permission, Role_RoleID) VALUES (4, 'TBD', 4);
INSERT INTO RolePermission (PermissionId, Permission, Role_RoleID) VALUES (5, 'TBD', 5);


-- Task 8 SQL Query--
SELECT DISTINCT u.UserID, u.Username, r.RoleName
FROM UserRole u
JOIN UserRoleMapping urm ON u.UserID = urm.UserID
JOIN Role r ON urm.RoleID = r.RoleID
WHERE r.RoleName = 'Caregiver'; 

SELECT res.ResidentID, res.Name, res.DateOfBirth, hr.Content
FROM Residents res
JOIN HealthRecord hr ON res.ResidentID = hr.ResidentID
WHERE TIMESTAMPDIFF(YEAR, res.DateOfBirth, CURDATE()) > 50;

SELECT u.UserID, u.Username, r.RoleName
FROM UserRole u
JOIN UserRoleMapping urm ON u.UserID = urm.UserID
JOIN Role r ON urm.RoleID = r.RoleID
WHERE r.RoleName = 'Admin';

SELECT r.RoleName, COUNT(urm.UserID) AS UserCount
FROM Role r
LEFT JOIN UserRoleMapping urm ON r.RoleID = urm.RoleID
GROUP BY r.RoleName
HAVING COUNT(urm.UserID) > 1;

 SELECT res.Name AS ResidentName, hr.Content AS HealthRecord, cl.Content AS CareLog
FROM Residents res
JOIN HealthRecord hr ON res.ResidentID = hr.ResidentID
LEFT JOIN CareLog cl ON res.ResidentID = cl.ResidentID;

SELECT *
FROM Residents
WHERE ResidentID IN (
    SELECT ResidentID
    FROM HealthRecord
    GROUP BY ResidentID
    HAVING COUNT(HealthRecordID) > 0
) AND (
    SELECT COUNT(DISTINCT ResidentID)
    FROM HealthRecord
) < (
    SELECT COUNT(*) * 0.6
    FROM Residents
); 

SELECT res.Name AS ResidentName, 
       COUNT(DISTINCT hr.HealthRecordID) AS HealthRecordCount, 
       COUNT(DISTINCT cl.CareLogID) AS CareLogCount
FROM Residents res
JOIN HealthRecord hr ON res.ResidentID = hr.ResidentID
JOIN CareLog cl ON res.ResidentID = cl.ResidentID
GROUP BY res.ResidentID
HAVING COUNT(hr.HealthRecordID) > 0 AND COUNT(cl.CareLogID) > 0;

