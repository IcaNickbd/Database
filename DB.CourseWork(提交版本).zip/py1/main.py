from flask import Flask, render_template, request, redirect, session, url_for
import pymysql

# Flask app 初始化
app = Flask(__name__)
app.secret_key = '114514'


# 数据库连接设置
def get_connection():
    timeout = 10
    connection = pymysql.connect(
        charset="utf8mb4",
        connect_timeout=timeout,
        cursorclass=pymysql.cursors.DictCursor,
        db="hospital1",  # 使用你的实际数据库名
        host="mysql-30ef2a65-liubeibeizz-2037.d.aivencloud.com",
        password="AVNS_x-T0LRSoZBR5f_7TTsB",
        read_timeout=timeout,
        port=14083,
        user="avnadmin",
        write_timeout=timeout,
    )
    return connection

@app.route('/')
def login():
    return render_template('login.html')

@app.route('/authenticate', methods=['POST'])
def authenticate():
    userID = request.form.get('UserID')
    password = request.form.get('password')

    if not userID or not password:
        return render_template('login.html', error_message="Please enter both UserID and Password.")

    connection = get_connection()
    try:
        with connection.cursor() as cursor:
            # 查询用户信息
            cursor.execute(
                "SELECT ur.UserID, ur.Password, urm.RoleID "
                "FROM UserRole ur JOIN UserRoleMapping urm ON ur.UserID = urm.UserID "
                "WHERE ur.UserID = %s",
                (userID,)
            )
            user = cursor.fetchone()

            if user:
                # 检查密码
                if user['Password'] == password:  # 如果密码加密，请替换为相应的哈希比较
                    session['UserID'] = user['UserID']
                    session['RoleID'] = user['RoleID']

                    # 跳转到对应角色页面
                    if user['RoleID'] == 1:
                        return redirect('/caregiver')
                    elif user['RoleID'] == 2:
                        return redirect('/nurse')
                    elif user['RoleID'] == 3:
                        return redirect('/admin')
                    else:
                        return "Role not found.", 403
                else:
                    return render_template('login.html', error_message="Invalid credentials. Please try again.")
            else:
                return render_template('login.html', error_message="Invalid credentials. Please try again.")
    finally:
        connection.close()




@app.route('/caregiver')
def caregiver():
    if session.get('RoleID') != 1:
        return "Access denied."

    caregiver_id = session['UserID']
    connection = get_connection()
    try:
        with connection.cursor() as cursor:
            # 获取分配给护理人员的所有护理记录
            query = """
                SELECT cl.CareLogID, cl.ResidentID, cl.CaregiverID, cl.Content AS CareDescription, cl.RecordTime AS CareDate
                FROM CareLog cl
                WHERE cl.CaregiverID = %s
            """
            cursor.execute(query, (caregiver_id,))
            care_logs = cursor.fetchall()
    finally:
        connection.close()

    return render_template('caregiver.html', care_logs=care_logs)


@app.route('/caregiver/save', methods=['POST'])
def save_care_record():
    if session.get('RoleID') != 1:
        return "Access denied."

    record_id = request.form.get('record_id')
    resident_id = request.form['resident_id']
    care_description = request.form['care_description']
    care_date = request.form['care_date']  # 从前端获取 datetime-local 数据
    caregiver_id = session['UserID']

    # 转换日期为 datetime 格式
    from datetime import datetime
    try:
        care_date = datetime.strptime(care_date, '%Y-%m-%dT%H:%M')  # 解析 datetime-local 格式
    except ValueError:
        return "Invalid date format.", 400

    connection = get_connection()
    try:
        with connection.cursor() as cursor:
            if record_id:  # 更新记录
                query = """
                    UPDATE CareLog
                    SET ResidentID = %s, Content = %s, RecordTime = %s
                    WHERE CareLogID = %s AND CaregiverID = %s
                """
                cursor.execute(query, (resident_id, care_description, care_date, record_id, caregiver_id))
            else:  # 插入新记录
                query = """
                    INSERT INTO CareLog (ResidentID, CaregiverID, Content, RecordTime)
                    VALUES (%s, %s, %s, %s)
                """
                cursor.execute(query, (resident_id, caregiver_id, care_description, care_date))
        connection.commit()
    finally:
        connection.close()

    # 修改后跳转到 Caregiver 页面
    return redirect('/caregiver')


@app.route('/caregiver/delete', methods=['POST'])
def delete_care_record():
    if session.get('RoleID') != 1:
        return "Access denied."

    record_id = request.form['record_id']
    caregiver_id = session['UserID']

    connection = get_connection()
    try:
        with connection.cursor() as cursor:
            query = "DELETE FROM CareLog WHERE CareLogID = %s AND CaregiverID = %s"
            cursor.execute(query, (record_id, caregiver_id))
        connection.commit()
    finally:
        connection.close()

    return redirect('/caregiver')


@app.route('/nurse')
def nurse():
    if session.get('RoleID') != 2:
        return "Access denied."

    nurse_id = session.get('UserID')
    connection = get_connection()
    try:
        with connection.cursor() as cursor:
            # 修正查询字段名，匹配数据库表结构
            query = """
                SELECT hr.HealthRecordID, hr.ResidentID, hr.RecordTime, hr.Content
                FROM HealthRecord hr
                WHERE hr.NurseID = %s
            """
            cursor.execute(query, (nurse_id,))
            visit_history = cursor.fetchall()
    finally:
        connection.close()

    return render_template('nurse.html', visit_history=visit_history)


from datetime import datetime

@app.route('/nurse/add_health_record', methods=['POST'])
def add_health_record():
    if session.get('RoleID') != 2:
        return "Access denied."

    resident_id = request.form['resident_id']
    treatment_summary = request.form['treatment_summary']
    visit_date = request.form['visit_date']
    nurse_id = session.get('UserID')

    # 转换 `visit_date` 为 `datetime`
    try:
        visit_date = datetime.strptime(visit_date, '%Y-%m-%dT%H:%M')  # 解析 `datetime-local` 数据
    except ValueError:
        return "Invalid date format.", 400

    connection = get_connection()
    try:
        with connection.cursor() as cursor:
            # 插入新记录
            query = """
                INSERT INTO HealthRecord (ResidentID, NurseID, Content, RecordTime)
                VALUES (%s, %s, %s, %s)
            """
            cursor.execute(query, (resident_id, nurse_id, treatment_summary, visit_date))
        connection.commit()
    finally:
        connection.close()

    # 添加记录后跳转到 dashboard_nurse 页面
    return redirect('/dashboard_nurse')



@app.route('/admin')
def admin():
    if session.get('RoleID') != 3:
        return "Access denied."
    
    connection = get_connection()
    try:
        with connection.cursor() as cursor:
            # 查询居民信息
            cursor.execute("SELECT * FROM Residents")
            residents = cursor.fetchall()

            # 查询活动日志
            cursor.execute("SELECT * FROM CareLog")
            activity_logs = cursor.fetchall()

            # 查询监护人信息
            cursor.execute("SELECT * FROM Guardians")
            guardians = cursor.fetchall()
    finally:
        connection.close()

    return render_template(
        'admin.html',
        residents=residents,
        activity_logs=activity_logs,
        guardians=guardians
    )


@app.route('/admin/assign_staff', methods=['POST'])
def assign_staff():
    if session.get('RoleID') != 3:
        return "Access denied."

    resident_id = request.form['resident_id']
    caregiver_id = request.form['caregiver_id']
    nurse_id = request.form['nurse_id']

    connection = get_connection()
    try:
        with connection.cursor() as cursor:
            # 确保居民已存在
            cursor.execute("SELECT ResidentID FROM Residents WHERE ResidentID = %s", (resident_id,))
            resident = cursor.fetchone()
            if not resident:
                return "Resident not found."

            # 更新居民的看护人员和护士
            # 这里可以根据业务需求设计更新操作
            # 如果要添加具体的关联数据，例如更新表格，请根据业务需求进行操作
            # 此处简单地返回操作完成的消息
            # 假设你有一个表来记录居民与护理人员的分配
            cursor.execute("""
                INSERT INTO ResidentStaffAssignments (ResidentID, CaregiverID, NurseID)
                VALUES (%s, %s, %s)
            """, (resident_id, caregiver_id, nurse_id))
        connection.commit()
    finally:
        connection.close()

    return redirect('/admin')


#dashboards
from flask import render_template, request, session, redirect
import mysql.connector

@app.route('/dashboard_care')
def dashboard_care():
    if session.get('RoleID') != 1:
        return "Access denied."

    caregiver_id = session['UserID']
    connection = get_connection()

    try:
        with connection.cursor() as cursor:
            # 查询 Caregiver 的所有护理记录
            query_care_logs = """
                SELECT cl.CareLogID, cl.ResidentID, cl.Content AS CareDescription, cl.RecordTime AS CareDate
                FROM CareLog cl
                WHERE cl.CaregiverID = %s
                ORDER BY cl.RecordTime DESC
            """
            cursor.execute(query_care_logs, (caregiver_id,))
            care_logs = cursor.fetchall()
    finally:
        connection.close()

    return render_template('dashboard_care.html', care_logs=care_logs)



@app.route('/dashboard_nurse')
def dashboard_nurse():
    if session.get('RoleID') != 2:
        return "Access denied."

    nurse_id = session['UserID']
    connection = get_connection()

    try:
        with connection.cursor() as cursor:
            # 查询 Nurse 的所有健康记录
            query_health_logs = """
                SELECT hr.HealthRecordID, hr.ResidentID, hr.Content AS TreatmentSummary, hr.RecordTime AS VisitDate
                FROM HealthRecord hr
                WHERE hr.NurseID = %s
                ORDER BY hr.RecordTime DESC
            """
            cursor.execute(query_health_logs, (nurse_id,))
            health_logs = cursor.fetchall()
    finally:
        connection.close()

    return render_template('dashboard_nurse.html', health_logs=health_logs)
@app.route('/dashboard_admin')
def dashboard_admin():
    if session.get('RoleID') != 3:
        return "Access denied."

    connection = get_connection()
    try:
        with connection.cursor() as cursor:
            # 查询居民信息
            cursor.execute("SELECT * FROM Residents")
            residents = cursor.fetchall()

            # 查询活动日志
            cursor.execute("SELECT * FROM CareLog")
            care_logs = cursor.fetchall()
    finally:
        connection.close()

    return render_template('dashboard_admin.html', residents=residents, care_logs=care_logs)



@app.route('/')
def index():
    return "Hello, World!"

if __name__ == '__main__':
    app.run(debug=True)


    